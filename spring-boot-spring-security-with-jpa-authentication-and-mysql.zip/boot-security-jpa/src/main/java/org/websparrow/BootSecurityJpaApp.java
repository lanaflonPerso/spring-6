package org.websparrow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootSecurityJpaApp {

	public static void main(String[] args) {
		SpringApplication.run(BootSecurityJpaApp.class, args);
	}
}
