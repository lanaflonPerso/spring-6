package com.spring.karim.restful.SpringRestFulBuilding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestFulBuildingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestFulBuildingApplication.class, args);
	}

}
