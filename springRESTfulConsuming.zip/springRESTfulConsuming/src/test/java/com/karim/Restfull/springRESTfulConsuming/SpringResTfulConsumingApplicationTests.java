package com.karim.Restfull.springRESTfulConsuming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringResTfulConsumingApplicationTests {

	@Test
	void contextLoads() {
	}

}
