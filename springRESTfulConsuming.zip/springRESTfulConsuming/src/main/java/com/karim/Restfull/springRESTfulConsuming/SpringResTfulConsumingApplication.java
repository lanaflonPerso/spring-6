package com.karim.Restfull.springRESTfulConsuming;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringResTfulConsumingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringResTfulConsumingApplication.class, args);
	}

}
