package com.karim.Restfull.springRESTfulBuilding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringResTfulBuildingApplicationTests {

	@Test
	void contextLoads() {
	}

}
