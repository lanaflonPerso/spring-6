package com.karim.Restfull.springRESTfulBuilding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringResTfulBuildingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringResTfulBuildingApplication.class, args);
	}

}
