package com.spring.karim.restful.controller;

public class HotelNotFoundException {

}
