package com.spring.karim.restful.controller;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.web.bind.annotation.RestController;


@RestController
public class GreetingController {

	
}