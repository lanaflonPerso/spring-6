package com.spring.consumingSOAPwebservice.springSOAPConsuming;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSoapConsumingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSoapConsumingApplication.class, args);
	}

}
